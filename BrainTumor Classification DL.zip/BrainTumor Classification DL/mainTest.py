import cv2
import os

from PIL import Image
from PIL import Image, ImageOps
import numpy as np
from sklearn.model_selection import train_test_split
from tensorflow import keras 
from keras.utils import normalize
from keras.models import Sequential
from keras.layers import Conv2D,MaxPooling2D
from keras.layers import Activation,Dropout,Flatten,Dense
from keras.models import load_model


model = load_model('BrainTumor10Epochscategorical.h5')

image = cv2.imread('C:\\Users\\Lenovo\\Downloads\\archive\\pred\\pred14.jpg')

img = Image.fromarray(image)
img=img.resize((64,64))

img= np.array(img)
img= np.expand_dims(img,axis=0)
#

predictions = (model.predict(img) > 0.5).astype("int32")
print(predictions[0][1])