import streamlit as st
import pickle
import pandas as pd
import requests
from PIL import Image
import cv2
import os

from PIL import Image
from PIL import Image, ImageOps
import numpy as np
from sklearn.model_selection import train_test_split
from tensorflow import keras 
from keras.utils import normalize
from keras.models import Sequential
from keras.layers import Conv2D,MaxPooling2D
from keras.layers import Activation,Dropout,Flatten,Dense
from keras.models import load_model

model = load_model('BrainTumor10Epochscategorical.h5')




st.title("Brain Tumor Detection")

uploaded_file = st.file_uploader("Choose an Image")
if uploaded_file is not None:
    
    st.write(uploaded_file.name)
    images= uploaded_file.name
    

    image = Image.open(images)

    st.image(image, caption='MRI Image')
    
  
    
    
    image = cv2.imread(images)
    
    
    img = Image.fromarray(image)
    img=img.resize((64,64))
    
    img= np.array(img)
    img= np.expand_dims(img,axis=0)
    #
    
    predictions = (model.predict(img) > 0.5).astype("int32")
    if (predictions[0][1])==1:
        st.header("Brain Tumor Detected")
    else:
        st.header("No Brain Tumor Detected")

